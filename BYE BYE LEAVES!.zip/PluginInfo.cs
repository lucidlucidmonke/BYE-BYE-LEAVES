﻿namespace GorillaTagModTemplateProject
{
	/// <summary>
	/// This class is used to provide information about your mod to BepInEx.
	/// </summary>
	class PluginInfo
	{
		public const string GUID = "com.lucid.byebyeleaves";
		public const string Name = "BYE BYE LEAVES!";
		public const string Version = "1.0.0";
	}
}
